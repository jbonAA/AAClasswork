class AddUseridToUsers < ActiveRecord::Migration[5.2]
  def change
    add_column :users, :userid, :integer, null: false
  end
end
