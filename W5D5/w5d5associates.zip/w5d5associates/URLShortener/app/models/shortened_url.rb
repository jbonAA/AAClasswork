require 'securerandom'

class ShortenedUrl < ApplicationRecord
  validates :long_url, :short_url, presence: true
  validates :short_url, uniqueness: true
  validates :userid, presence: true, uniqueness: true

  attr_writer :short_url

  def self.random_code
    short_url = SecureRandom.urlsafe_base64
    if ShortenedUrl.where(short_url: short_url).exists?
      short_url = SecureRandom.urlsafe_base64
    else
      return short_url
    end
  end

  def factory(user, long_url)
    ShortenedUrl.create!(short_url: ShortenedUrl.random_code, long_url: long_url, userid: user.userid)
  end
end