class Course < ApplicationRecord

has_many :enrollments,
  primary_key: :id,
  foreign_key: :course_id,
  class_name: :Enrollment

has_many :enrolled_students,
  primary_key: :id,
  foreign_key: :student_id,
  class_name: :Enrollment

has_many :prerequisites,
  through: :enrollments,
  source: :course
end
